package com.cinemax.cinamaxbackend.service;

import com.cinemax.cinamaxbackend.dto.Room.RoomDTO;
import java.util.List;

public interface RoomService {
    List<RoomDTO> getRoomsByCinemaId(Long cinemaId);
}