package com.cinemax.cinamaxbackend.mapper;

import com.cinemax.cinamaxbackend.dto.Room.RoomDTO;
import com.cinemax.cinamaxbackend.entity.Room;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface RoomMapper {

    // Chuyển từ Room Entity sang RoomDTO
    RoomDTO toDto(Room room);

    // Chuyển từ RoomDTO sang Room Entity
    // Chúng ta bỏ qua trường "cinema" vì nó sẽ được set thủ công ở service
    @Mapping(target = "cinema", ignore = true)
    Room toEntity(RoomDTO roomDTO);
}
