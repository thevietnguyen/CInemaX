package com.cinemax.cinamaxbackend.service;

import com.cinemax.cinamaxbackend.dto.Showtime.ShowtimeRequestDTO;
import com.cinemax.cinamaxbackend.dto.Showtime.ShowtimeResponseDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface ShowtimeService {
    ShowtimeResponseDTO createShowtime(ShowtimeRequestDTO requestDTO);
    Page<ShowtimeResponseDTO> getAllShowtimes(Pageable pageable);
    void deleteShowtime(Long id);
    // Có thể thêm updateShowtime nếu cần
}
