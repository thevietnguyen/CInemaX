package com.cinemax.cinamaxbackend.service.impl;

import com.cinemax.cinamaxbackend.dto.Room.RoomDTO;
import com.cinemax.cinamaxbackend.entity.Cinema;
import com.cinemax.cinamaxbackend.mapper.RoomMapper;
import com.cinemax.cinamaxbackend.repository.CinemaRepository;
import com.cinemax.cinamaxbackend.service.RoomService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class RoomServiceImpl implements RoomService {

    private final CinemaRepository cinemaRepository;
    private final RoomMapper roomMapper;

    @Override
    public List<RoomDTO> getRoomsByCinemaId(Long cinemaId) {
        // Tìm rạp phim theo ID, nếu không thấy sẽ ném lỗi
        Cinema cinema = cinemaRepository.findById(cinemaId)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy rạp phim với ID: " + cinemaId));

        // Lấy danh sách phòng từ rạp phim và chuyển đổi sang DTO
        return cinema.getRooms().stream()
                .map(roomMapper::toDto)
                .collect(Collectors.toList());
    }
}