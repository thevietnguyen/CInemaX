package com.cinemax.cinamaxbackend.mapper;

import com.cinemax.cinamaxbackend.dto.Showtime.ShowtimeResponseDTO;
import com.cinemax.cinamaxbackend.entity.Showtime;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface ShowtimeMapper {

    // Ánh xạ các trường lồng nhau từ Entity sang DTO
    @Mapping(source = "movie.title", target = "movieTitle")
    @Mapping(source = "room.name", target = "roomName")
    @Mapping(source = "room.cinema.name", target = "cinemaName")
    ShowtimeResponseDTO toResponseDTO(Showtime showtime);
}
