package com.cinemax.cinamaxbackend.enums;

public enum MovieStatus {
    NOW_SHOWING,
    COMING_SOON,
    ENDED
}