package com.cinemax.cinamaxbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CinamaxBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
