package com.cinemax.cinamaxbackend.dto.Room;

import lombok.Data;

@Data
public class RoomDTO {
    private Long id;
    private String name;
    private int capacity;
}
