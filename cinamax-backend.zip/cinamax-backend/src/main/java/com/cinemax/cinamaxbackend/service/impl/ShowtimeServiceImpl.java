package com.cinemax.cinamaxbackend.service.impl;

import com.cinemax.cinamaxbackend.dto.Showtime.ShowtimeRequestDTO;
import com.cinemax.cinamaxbackend.dto.Showtime.ShowtimeResponseDTO;
import com.cinemax.cinamaxbackend.entity.Movie;
import com.cinemax.cinamaxbackend.entity.Room;
import com.cinemax.cinamaxbackend.entity.Showtime;
import com.cinemax.cinamaxbackend.mapper.ShowtimeMapper;
import com.cinemax.cinamaxbackend.repository.MovieRepository;
import com.cinemax.cinamaxbackend.repository.RoomRepository;
import com.cinemax.cinamaxbackend.repository.ShowtimeRepository;
import com.cinemax.cinamaxbackend.service.ShowtimeService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ShowtimeServiceImpl implements ShowtimeService {

    private final ShowtimeRepository showtimeRepository;
    private final MovieRepository movieRepository;
    private final RoomRepository roomRepository;
    private final ShowtimeMapper showtimeMapper;

    @Override
    public ShowtimeResponseDTO createShowtime(ShowtimeRequestDTO requestDTO) {
        Movie movie = movieRepository.findById(requestDTO.getMovieId())
                .orElseThrow(() -> new RuntimeException("Phim không tồn tại"));
        Room room = roomRepository.findById(requestDTO.getRoomId())
                .orElseThrow(() -> new RuntimeException("Phòng chiếu không tồn tại"));

        LocalDateTime startTime = requestDTO.getStartTime();
        LocalDateTime endTime = startTime.plusMinutes(movie.getDurationInMinutes());

        // Kiểm tra xung đột lịch chiếu
        List<Showtime> conflicting = showtimeRepository.findConflictingShowtimes(room.getId(), startTime, endTime);
        if (!conflicting.isEmpty()) {
            throw new RuntimeException("Lịch chiếu bị trùng lặp trong phòng này vào thời gian đã chọn.");
        }

        Showtime newShowtime = Showtime.builder()
                .movie(movie)
                .room(room)
                .startTime(startTime)
                .endTime(endTime)
                .price(requestDTO.getPrice())
                .build();

        Showtime savedShowtime = showtimeRepository.save(newShowtime);
        return showtimeMapper.toResponseDTO(savedShowtime);
    }

    @Override
    public Page<ShowtimeResponseDTO> getAllShowtimes(Pageable pageable) {
        return showtimeRepository.findAll(pageable).map(showtimeMapper::toResponseDTO);
    }

    @Override
    public void deleteShowtime(Long id) {
        if (!showtimeRepository.existsById(id)) {
            throw new RuntimeException("Suất chiếu không tồn tại.");
        }
        showtimeRepository.deleteById(id);
    }
}
