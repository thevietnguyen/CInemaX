package com.cinemax.cinamaxbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CinamaxBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(CinamaxBackendApplication.class, args);
	}

}
