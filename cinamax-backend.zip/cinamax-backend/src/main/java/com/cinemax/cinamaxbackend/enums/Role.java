package com.cinemax.cinamaxbackend.enums;

public enum Role {
    USER,
    ADMIN
}
