package com.cinemax.cinamaxbackend.dto.Showtime;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class ShowtimeResponseDTO {
    private Long id;
    private String movieTitle;
    private String cinemaName;
    private String roomName;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private BigDecimal price;
}
