package com.cinemax.cinamaxbackend.controller.admin;

import com.cinemax.cinamaxbackend.dto.Cinema.CinemaRequestDTO;
import com.cinemax.cinamaxbackend.dto.Cinema.CinemaResponseDTO;
import com.cinemax.cinamaxbackend.service.CinemaService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;


// controller/admin/AdminCinemaController.java
@RestController
@RequestMapping("/api/admin/cinemas")
@RequiredArgsConstructor
public class AdminCinemaController {
    private final CinemaService cinemaService;

    @PostMapping("/create")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<CinemaResponseDTO> createCinema(@RequestBody CinemaRequestDTO requestDTO) {
        return new ResponseEntity<>(cinemaService.createCinema(requestDTO), HttpStatus.CREATED);
    }

    @PutMapping("/{id}/update")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<CinemaResponseDTO> updateCinema(@PathVariable Long id, @RequestBody CinemaRequestDTO requestDTO) {
        return ResponseEntity.ok(cinemaService.updateCinema(id, requestDTO));
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public Page<CinemaResponseDTO> getCinemas(Pageable pageable, @RequestParam(required = false) String query) {
        return cinemaService.getAllCinemas(pageable, query);
    }

    // Endpoint này rất quan trọng cho trang tạo lịch chiếu
    @GetMapping("/with-rooms")
    @PreAuthorize("hasRole('ADMIN')")
    public List<CinemaResponseDTO> getCinemasWithRooms() {
        return cinemaService.getAllCinemasWithRooms();
    }

    @DeleteMapping("/{id}/delete")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> deleteCinema(@PathVariable Long id) {
        cinemaService.deleteCinema(id);
        return ResponseEntity.noContent().build();
    }
}
